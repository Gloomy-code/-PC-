export default {
  setUser(state, user) {
    state.user = user
  },
  setUserPlaylist(state, playlist) {
    state.userPlaylist = playlist
  }
}
