export default {
  setAxiosLoading(state, loading) {
    state.axiosLoading = loading
  },
}
